// src/types.ts
var DEFAULT_SETTINGS = {
  enabled: true,
  aiEnabled: false,
  userLevel: "A2",
  threshold: "B1",
  backendUrl: "http://localhost:8000",
  position: "bottom"
};

// src/background/index.ts
chrome.runtime.onInstalled.addListener(async () => {
  console.log("[GermanTutor] Extension installed.");
  const stored = await chrome.storage.local.get(DEFAULT_SETTINGS);
  await chrome.storage.local.set({ ...DEFAULT_SETTINGS, ...stored });
});
//# sourceMappingURL=background.js.map
