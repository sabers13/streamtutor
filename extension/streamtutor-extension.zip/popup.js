// src/types.ts
var DEFAULT_SETTINGS = {
  enabled: true,
  aiEnabled: false,
  userLevel: "A2",
  threshold: "B1",
  backendUrl: "http://localhost:8000",
  position: "bottom"
};

// src/utils/normalizer.ts
var HTML_ENTITY_MAP = {
  "&quot;": '"',
  "&apos;": "'",
  "&#39;": "'",
  "&amp;": "&",
  "&lt;": "<",
  "&gt;": ">",
  "&nbsp;": " ",
  "&auml;": "\xE4",
  "&ouml;": "\xF6",
  "&uuml;": "\xFC",
  "&szlig;": "\xDF",
  "&Auml;": "\xC4",
  "&Ouml;": "\xD6",
  "&Uuml;": "\xDC"
};
function unescapeHtml(text) {
  if (!text) return "";
  return text.replace(/&(?:[a-zA-Z]+|#\d+|#x[a-fA-F0-9]+);/g, (match) => {
    if (HTML_ENTITY_MAP[match]) return HTML_ENTITY_MAP[match];
    if (match.startsWith("&#x")) {
      const hex = match.slice(3, -1);
      return String.fromCharCode(parseInt(hex, 16));
    }
    if (match.startsWith("&#")) {
      const dec = match.slice(2, -1);
      return String.fromCharCode(parseInt(dec, 10));
    }
    return match;
  });
}
function normalizeSubtitleText(raw) {
  if (!raw) return "";
  const unescaped = unescapeHtml(raw);
  const noTags = unescaped.replace(/<[^>]+>/g, " ");
  const singleLine = noTags.replace(/[\r\n]+/g, " ");
  const noDash = singleLine.replace(/^[-–—]\s*/, "");
  const cleanPunctuation = noDash.replace(/\s+([,.:;!?])/g, "$1");
  return cleanPunctuation.replace(/\s+/g, " ").trim();
}
function canonicalTextForMatch(text) {
  const norm = normalizeSubtitleText(text).toLowerCase();
  return norm.replace(/^[„“"«»'…\-—\s]+|[„“"«»'…!?:;.,\s]+$/g, "").trim();
}

// src/services/backend-client.ts
var BackendClient = class {
  memoryCache = /* @__PURE__ */ new Map();
  defaultBackendUrl = "http://localhost:8000";
  constructor(backendUrl) {
    if (backendUrl) {
      this.defaultBackendUrl = backendUrl.replace(/\/+$/, "");
    }
  }
  setBackendUrl(url) {
    this.defaultBackendUrl = url.replace(/\/+$/, "");
  }
  getCacheKey(text, previous, next, userLevel, threshold, aiEnabled) {
    const t = canonicalTextForMatch(text);
    const p = previous ? canonicalTextForMatch(previous) : "";
    const n = next ? canonicalTextForMatch(next) : "";
    return `${t}__${p}__${n}__${userLevel || "A2"}__${threshold || "B1"}__ai:${aiEnabled !== false}`;
  }
  async checkHealth(backendUrl) {
    const base = (backendUrl || this.defaultBackendUrl).replace(/\/+$/, "");
    try {
      const response = await fetch(`${base}/health`, {
        method: "GET",
        headers: { "Accept": "application/json" }
      });
      if (!response.ok) {
        return { ok: false, error: `HTTP ${response.status}: ${response.statusText}` };
      }
      const data = await response.json();
      return { ok: true, data };
    } catch (err) {
      return { ok: false, error: err?.message || "Failed to connect to backend" };
    }
  }
  async analyzeSentence(text, options) {
    const cleanText = normalizeSubtitleText(text);
    if (!cleanText) return null;
    const userLevel = options?.userLevel || "A2";
    const threshold = options?.threshold || "B1";
    const aiEnabled = options?.aiEnabled !== false;
    const backendUrl = (options?.backendUrl || this.defaultBackendUrl).replace(/\/+$/, "");
    const cacheKey = this.getCacheKey(cleanText, options?.previous, options?.next, userLevel, threshold, aiEnabled);
    if (this.memoryCache.has(cacheKey)) {
      return this.memoryCache.get(cacheKey);
    }
    const payload = {
      text: cleanText,
      previous: options?.previous,
      next: options?.next,
      user_level: userLevel,
      threshold,
      ai_enabled: aiEnabled
    };
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 8e3);
      const response = await fetch(`${backendUrl}/analyze-sentence`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify(payload),
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (!response.ok) {
        console.warn(`[GermanTutor] Backend returned HTTP ${response.status}: ${response.statusText}`);
        return null;
      }
      const data = await response.json();
      this.memoryCache.set(cacheKey, data);
      return data;
    } catch (err) {
      console.warn("[GermanTutor] Error requesting sentence analysis from backend:", err);
      return null;
    }
  }
  async explainSentence(text, options) {
    const cleanText = normalizeSubtitleText(text);
    if (!cleanText) return null;
    const backendUrl = (options?.backendUrl || this.defaultBackendUrl).replace(/\/+$/, "");
    const payload = {
      text: cleanText,
      previous: options?.previous,
      next: options?.next,
      user_level: options?.userLevel || "A2"
    };
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 12e3);
      const response = await fetch(`${backendUrl}/explain-sentence`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify(payload),
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (!response.ok) {
        console.warn(`[GermanTutor] Explain returned HTTP ${response.status}`);
        return null;
      }
      const data = await response.json();
      return data.explanation || null;
    } catch (err) {
      console.warn("[GermanTutor] Error requesting explanation from backend:", err);
      return null;
    }
  }
  async lookupWord(word, backendUrl) {
    const clean = word.trim().replace(/^[.,!?:;"'()«»]+|[.,!?:;"'()«»]+$/g, "");
    if (!clean) return null;
    const cacheKey = `word::${clean.toLowerCase()}`;
    if (this.memoryCache.has(cacheKey)) {
      return this.memoryCache.get(cacheKey);
    }
    const base = (backendUrl || this.defaultBackendUrl).replace(/\/+$/, "");
    try {
      const response = await fetch(`${base}/lookup-word?word=${encodeURIComponent(clean)}`, {
        method: "GET",
        headers: { Accept: "application/json" }
      });
      if (!response.ok) return null;
      const data = await response.json();
      this.memoryCache.set(cacheKey, data);
      return data;
    } catch (err) {
      console.warn("[GermanTutor] Error looking up word:", err);
      return null;
    }
  }
  async saveFlashcard(req, backendUrl) {
    const base = (backendUrl || this.defaultBackendUrl).replace(/\/+$/, "");
    try {
      const response = await fetch(`${base}/save-flashcard`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json"
        },
        body: JSON.stringify(req)
      });
      if (!response.ok) return null;
      return await response.json();
    } catch (err) {
      console.warn("[GermanTutor] Error saving flashcard:", err);
      return null;
    }
  }
  async getFlashcardCount(backendUrl) {
    const base = (backendUrl || this.defaultBackendUrl).replace(/\/+$/, "");
    try {
      const response = await fetch(`${base}/flashcard-count`, {
        method: "GET",
        headers: { Accept: "application/json" }
      });
      if (!response.ok) return 0;
      const data = await response.json();
      return data.count ?? 0;
    } catch {
      return 0;
    }
  }
  getExportUrl(format = "csv", backendUrl) {
    const base = (backendUrl || this.defaultBackendUrl).replace(/\/+$/, "");
    return `${base}/export-flashcards?format=${encodeURIComponent(format)}`;
  }
  async clearFlashcards(backendUrl) {
    const base = (backendUrl || this.defaultBackendUrl).replace(/\/+$/, "");
    try {
      const response = await fetch(`${base}/flashcards`, {
        method: "DELETE",
        headers: { Accept: "application/json" }
      });
      return response.ok;
    } catch {
      return false;
    }
  }
  clearMemoryCache() {
    this.memoryCache.clear();
  }
};
var backendClient = new BackendClient();

// src/popup/index.ts
document.addEventListener("DOMContentLoaded", async () => {
  const tutorEnabledInput = document.getElementById("tutor-enabled");
  const aiEnabledInput = document.getElementById("ai-enabled");
  const thresholdSelect = document.getElementById("threshold-select");
  const userLevelSelect = document.getElementById("user-level-select");
  const positionSelect = document.getElementById("position-select");
  const backendUrlInput = document.getElementById("backend-url");
  const checkBackendBtn = document.getElementById("check-backend-btn");
  const backendStatusBadge = document.getElementById("backend-status-badge");
  const backendDetails = document.getElementById("backend-details");
  const openTestPageBtn = document.getElementById("open-test-page-btn");
  let settings = { ...DEFAULT_SETTINGS };
  try {
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
      const stored = await chrome.storage.local.get(DEFAULT_SETTINGS);
      settings = { ...DEFAULT_SETTINGS, ...stored };
    }
  } catch (e) {
    console.warn("Storage read error:", e);
  }
  tutorEnabledInput.checked = settings.enabled;
  if (aiEnabledInput) aiEnabledInput.checked = settings.aiEnabled !== false;
  thresholdSelect.value = settings.threshold;
  userLevelSelect.value = settings.userLevel;
  if (positionSelect) positionSelect.value = settings.position || "bottom";
  backendUrlInput.value = settings.backendUrl;
  const save = async (changes) => {
    settings = { ...settings, ...changes };
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
      await chrome.storage.local.set(settings);
    }
  };
  tutorEnabledInput.addEventListener("change", () => {
    save({ enabled: tutorEnabledInput.checked });
  });
  if (aiEnabledInput) {
    aiEnabledInput.addEventListener("change", () => {
      save({ aiEnabled: aiEnabledInput.checked });
    });
  }
  thresholdSelect.addEventListener("change", () => {
    save({ threshold: thresholdSelect.value });
  });
  userLevelSelect.addEventListener("change", () => {
    save({ userLevel: userLevelSelect.value });
  });
  if (positionSelect) {
    positionSelect.addEventListener("change", () => {
      save({ position: positionSelect.value });
    });
  }
  backendUrlInput.addEventListener("change", () => {
    const cleanUrl = backendUrlInput.value.trim().replace(/\/+$/, "");
    save({ backendUrl: cleanUrl });
    checkBackend();
  });
  const flashcardCountBadge = document.getElementById("flashcard-count-badge");
  const downloadCsvBtn = document.getElementById("download-csv-btn");
  const clearFlashcardsBtn = document.getElementById("clear-flashcards-btn");
  const updateFlashcardCount = async () => {
    if (!flashcardCountBadge) return;
    const url = backendUrlInput.value.trim();
    const count = await backendClient.getFlashcardCount(url);
    flashcardCountBadge.textContent = `${count} saved`;
  };
  if (downloadCsvBtn) {
    downloadCsvBtn.addEventListener("click", () => {
      const url = backendUrlInput.value.trim();
      const exportUrl = backendClient.getExportUrl("csv", url);
      if (typeof chrome !== "undefined" && chrome.tabs) {
        chrome.tabs.create({ url: exportUrl });
      } else {
        window.open(exportUrl, "_blank");
      }
    });
  }
  if (clearFlashcardsBtn) {
    clearFlashcardsBtn.addEventListener("click", async () => {
      if (!confirm("Clear all saved flashcards from file and database?")) return;
      const url = backendUrlInput.value.trim();
      await backendClient.clearFlashcards(url);
      await updateFlashcardCount();
    });
  }
  const checkBackend = async () => {
    const url = backendUrlInput.value.trim();
    backendStatusBadge.textContent = "Checking...";
    backendStatusBadge.className = "badge";
    const res = await backendClient.checkHealth(url);
    if (res.ok) {
      backendStatusBadge.textContent = "Online";
      backendStatusBadge.className = "badge badge-online";
      const count = res.data?.cache_entries ?? 0;
      const prov = res.data?.provider ?? "ready";
      backendDetails.textContent = `Provider: ${prov} \u2022 Cached items: ${count}`;
      updateFlashcardCount();
    } else {
      backendStatusBadge.textContent = "Offline";
      backendStatusBadge.className = "badge badge-offline";
      backendDetails.textContent = `Error: ${res.error}`;
    }
  };
  checkBackendBtn.addEventListener("click", checkBackend);
  openTestPageBtn.addEventListener("click", () => {
    if (typeof chrome !== "undefined" && chrome.tabs) {
      chrome.tabs.create({ url: chrome.runtime.getURL("test-page.html") });
    } else {
      window.open("test-page.html", "_blank");
    }
  });
  checkBackend();
  updateFlashcardCount();
});
//# sourceMappingURL=popup.js.map
